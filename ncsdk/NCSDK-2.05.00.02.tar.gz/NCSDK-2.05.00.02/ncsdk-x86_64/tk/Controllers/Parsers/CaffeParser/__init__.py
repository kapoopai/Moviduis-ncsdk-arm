# #!/usr/bin/env python3

import Controllers.Parsers.CaffeParser.Pooling
import Controllers.Parsers.CaffeParser.Bias
import Controllers.Parsers.CaffeParser.Convolution
import Controllers.Parsers.CaffeParser.Input
import Controllers.Parsers.CaffeParser.ReLU
import Controllers.Parsers.CaffeParser.Concat
import Controllers.Parsers.CaffeParser.Slice
import Controllers.Parsers.CaffeParser.Eltwise
import Controllers.Parsers.CaffeParser.ELU
import Controllers.Parsers.CaffeParser.PReLU
import Controllers.Parsers.CaffeParser.LRN
import Controllers.Parsers.CaffeParser.InnerProduct
import Controllers.Parsers.CaffeParser.Softmax
import Controllers.Parsers.CaffeParser.Sigmoid
import Controllers.Parsers.CaffeParser.BatchNorm
import Controllers.Parsers.CaffeParser.Scale
import Controllers.Parsers.CaffeParser.Reshape
import Controllers.Parsers.CaffeParser.Dropout
import Controllers.Parsers.CaffeParser.permute
import Controllers.Parsers.CaffeParser.Normalize
import Controllers.Parsers.CaffeParser.PriorBox
import Controllers.Parsers.CaffeParser.DetectionOutput
import Controllers.Parsers.CaffeParser.Flatten
import Controllers.Parsers.CaffeParser.Deconvolution
import Controllers.Parsers.CaffeParser.tan_h
import Controllers.Parsers.CaffeParser.crop